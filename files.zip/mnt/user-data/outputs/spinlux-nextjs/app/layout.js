// app/layout.js  (root layout – minimal, no lang here)
export default function RootLayout({ children }) {
  return children
}

// app/page.js
// Fallback for "/" when middleware doesn't redirect (e.g. static export).
// Redirects to /en.

import { redirect } from 'next/navigation'

export default function Home() {
  redirect('/en')
}

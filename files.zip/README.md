# SpinLux – Next.js SEO-Friendly Structure

## 📁 Structure des fichiers

```
spinlux/
├── middleware.js                  ← Détection langue navigateur + redirect /
├── next.config.js
├── package.json
│
├── app/
│   ├── layout.js                  ← Root layout minimal (ne rend que children)
│   ├── page.js                    ← Fallback "/" → redirect /en
│   └── [lang]/
│       ├── layout.js              ← Layout par langue : html lang, hreflang, SEO metadata
│       └── page.js                ← Page : valide le lang, rend <SpinWheel lang="fr" />
│
├── components/
│   └── SpinWheel.jsx              ← Tout le code de la roue (Client Component)
│
└── lib/
    └── translations.js            ← TRANSLATIONS, SEO_META, t(), SUPPORTED_LANGS, BASE_URL
```

## 🔑 Concepts clés

### 1. Une seule URL par langue
- `/fr` → roue en français
- `/en` → roue en anglais  
- `/es` → roue en espagnol

### 2. Zéro duplication de code
Le composant `SpinWheel` est unique. Il reçoit `lang` en prop depuis la page serveur.

```jsx
// app/[lang]/page.js
import SpinWheel from '@/components/SpinWheel'
export default async function WheelPage({ params }) {
  const { lang } = await params
  return <SpinWheel lang={lang} />
}
```

### 3. Changement de langue = changement d'URL
```jsx
// Dans SpinWheel.jsx
const router = useRouter()
const switchLang = (newLang) => router.push(`/${newLang}`)
```

### 4. SEO complet automatique
`app/[lang]/layout.js` génère via `generateMetadata()` :
- `<html lang="fr">` (ou en/es)
- `<title>` différent par langue
- `<meta name="description">` localisée
- `<link rel="alternate" hreflang="fr" href="...">` × 3 langues
- Open Graph + Twitter Cards

### 5. Redirection automatique selon le navigateur
`middleware.js` intercepte `/` et lit le header `Accept-Language` :
```
/ + Accept-Language: fr-FR → redirect /fr
/ + Accept-Language: es    → redirect /es
/ + Accept-Language: zh    → redirect /en (fallback)
```

## 🚀 Déploiement Vercel

```bash
npm install
vercel deploy
```

Le middleware s'exécute à l'edge automatiquement sur Vercel.
Aucune config supplémentaire nécessaire.

## ⚙️ Configuration

Dans `lib/translations.js`, mets à jour :
```js
export const BASE_URL = 'https://ton-domaine.vercel.app'
```

## 📧 Contact

L'icône mail dans le header redirige vers `donkari.contact@gmail.com`.
Pour le modifier : chercher `CONTACT_EMAIL` dans `components/SpinWheel.jsx`.

## 🎯 Performance

- Canvas 2D `will-change: transform` pour 60fps
- `'use client'` uniquement sur le composant wheel
- Pages `/fr`, `/en`, `/es` pré-rendues statiquement (`generateStaticParams`)
- Middleware edge (< 1ms de latence)
